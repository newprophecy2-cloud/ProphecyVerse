package com.example.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.data.remote.DirectPlayData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlayerManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var exoPlayer: ExoPlayer? = null
    private var tickerJob: Job? = null

    private val _exoPlayerInstance = MutableStateFlow<ExoPlayer?>(null)
    val exoPlayerInstance: StateFlow<ExoPlayer?> = _exoPlayerInstance.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<TrackOption>>(emptyList())
    val availableAudioTracks: StateFlow<List<TrackOption>> = _availableAudioTracks.asStateFlow()

    private val _availableSubtitles = MutableStateFlow<List<TrackOption>>(emptyList())
    val availableSubtitles: StateFlow<List<TrackOption>> = _availableSubtitles.asStateFlow()

    private val _availableQualities = MutableStateFlow<List<TrackOption>>(emptyList())
    val availableQualities: StateFlow<List<TrackOption>> = _availableQualities.asStateFlow()

    private var retryCount = 0
    private var onRetryRequested: (() -> Unit)? = null
    var onPositionUpdate: ((positionMs: Long, durationMs: Long) -> Unit)? = null

    data class TrackOption(
        val id: String,
        val label: String,
        val isSelected: Boolean,
        val trackGroup: TrackGroup? = null,
        val trackIndex: Int = 0
    )

    fun initializePlayer(
        directData: DirectPlayData,
        startPositionMs: Long = 0L,
        onRetryNeeded: () -> Unit
    ): ExoPlayer {
        release()
        onRetryRequested = onRetryNeeded
        _errorMessage.value = null

        // Build safe HTTP DataSource with only response-authorized headers
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(25000)

        // Add headers from direct play response
        if (directData.headers.isNotEmpty()) {
            val headerMap = mutableMapOf<String, String>()
            for (headerPair in directData.headers) {
                if (headerPair.size >= 2) {
                    val key = headerPair[0]
                    val value = headerPair[1]
                    if (key.equals("User-Agent", ignoreCase = true)) {
                        httpDataSourceFactory.setUserAgent(value)
                    } else {
                        headerMap[key] = value
                    }
                }
            }
            if (headerMap.isNotEmpty()) {
                httpDataSourceFactory.setDefaultRequestProperties(headerMap)
            }
        } else {
            httpDataSourceFactory.setUserAgent("ProphecyVerse/1.0 (Android)")
        }

        val renderersFactory = object : androidx.media3.exoplayer.DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink {
                return androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioCapabilities(
                        androidx.media3.exoplayer.audio.AudioCapabilities(
                            intArrayOf(
                                android.media.AudioFormat.ENCODING_PCM_16BIT,
                                android.media.AudioFormat.ENCODING_PCM_FLOAT
                            ),
                            8
                        )
                    )
                    .build()
            }
        }.apply {
            setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ 2000,
                /* maxBufferMs = */ 15000,
                /* bufferForPlaybackMs = */ 800,
                /* bufferForPlaybackAfterRebufferMs = */ 1500
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        // Unmute device media stream if muted
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
            audioManager?.let { am ->
                val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                if (max > 0) {
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, max, 0)
                }
            }
        } catch (e: Exception) {
            // Ignore system restrictions
        }

        val mediaSourceFactory = DefaultMediaSourceFactory(httpDataSourceFactory)

        val player = ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                playWhenReady = true
                volume = 1.0f
                trackSelectionParameters = trackSelectionParameters
                    .buildUpon()
                    .setPreferredAudioLanguages("ja", "jpn", "en", "eng", "hi", "hin")
                    .build()
                val mediaItem = MediaItem.fromUri(directData.playbackUrl)
                setMediaItem(mediaItem, startPositionMs)
                prepare()
                play()
            }

        _exoPlayerInstance.value = player
        exoPlayer = player

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        _isBuffering.value = true
                    }
                    Player.STATE_READY -> {
                        _isBuffering.value = false
                        _duration.value = player.duration.coerceAtLeast(0L)
                        retryCount = 0 // Reset on successful playback
                    }
                    Player.STATE_ENDED -> {
                        _isBuffering.value = false
                        _isPlaying.value = false
                    }
                    Player.STATE_IDLE -> {
                        _isBuffering.value = false
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractTracks(tracks)
            }

            override fun onPlayerError(error: PlaybackException) {
                _isBuffering.value = false
                val isResolvableHttp = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE

                if (isResolvableHttp && retryCount < 1) {
                    retryCount++
                    _errorMessage.value = "Playback link expired or connection dropped. Refreshing..."
                    onRetryRequested?.invoke()
                } else {
                    val msg = when (error.errorCode) {
                        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "Source unavailable (HTTP error)"
                        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "Hardware decoder unsupported on device"
                        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED -> "Media format not supported by device"
                        else -> "Playback error encountered. Please select another source."
                    }
                    _errorMessage.value = msg
                }
            }
        })

        exoPlayer = player
        startPositionTicker()
        return player
    }

    private fun extractTracks(tracks: Tracks) {
        val audioList = mutableListOf<TrackOption>()
        val subList = mutableListOf<TrackOption>()
        val qualityList = mutableListOf<TrackOption>()

        var anyAudioSelected = false
        var anySubSelected = false
        var anyVideoSelected = false

        for ((groupIndex, groupInfo) in tracks.groups.withIndex()) {
            val trackGroup = groupInfo.mediaTrackGroup
            val type = trackGroup.type

            for (i in 0 until trackGroup.length) {
                val format = trackGroup.getFormat(i)
                val isSelected = groupInfo.isTrackSelected(i)

                when (type) {
                    C.TRACK_TYPE_AUDIO -> {
                        val lang = getDisplayLanguage(format.language)
                        val codec = format.sampleMimeType?.substringAfterLast('/')?.uppercase() ?: ""
                        val label = if (codec.isNotBlank()) "$lang ($codec)" else lang
                        val uniqueId = "audio_${groupIndex}_${i}"
                        if (isSelected) anyAudioSelected = true
                        audioList.add(TrackOption(uniqueId, label, isSelected, trackGroup, i))
                    }
                    C.TRACK_TYPE_TEXT -> {
                        val lang = getDisplayLanguage(format.language)
                        val uniqueId = "sub_${groupIndex}_${i}"
                        if (isSelected) anySubSelected = true
                        subList.add(TrackOption(uniqueId, lang, isSelected, trackGroup, i))
                    }
                    C.TRACK_TYPE_VIDEO -> {
                        if (format.height > 0) {
                            val label = "${format.height}p" + (if (format.frameRate > 0) " (${format.frameRate.toInt()}fps)" else "")
                            val uniqueId = "video_${groupIndex}_${i}"
                            if (isSelected) anyVideoSelected = true
                            qualityList.add(TrackOption(uniqueId, label, isSelected, trackGroup, i))
                        }
                    }
                }
            }
        }

        // Add Auto/Default options at the front with guaranteed unique IDs
        audioList.add(0, TrackOption("auto_audio", "Default Audio", isSelected = !anyAudioSelected))
        subList.add(0, TrackOption("off_sub", "Subtitles Off", isSelected = !anySubSelected))
        qualityList.add(0, TrackOption("auto_video", "Auto Quality", isSelected = !anyVideoSelected))

        _availableAudioTracks.value = audioList
        _availableSubtitles.value = subList
        _availableQualities.value = qualityList
    }

    private fun getDisplayLanguage(langCode: String?): String {
        return when (langCode?.lowercase()) {
            "jpn", "ja", "japanese" -> "Japanese"
            "eng", "en", "english" -> "English"
            "hin", "hi", "hindi" -> "Hindi"
            "tam", "ta", "tamil" -> "Tamil"
            "tel", "te", "telugu" -> "Telugu"
            "spa", "es", "spanish" -> "Spanish"
            null, "" -> "Audio"
            else -> langCode.uppercase()
        }
    }

    fun selectTrack(option: TrackOption) {
        val player = exoPlayer ?: return
        when (option.id) {
            "auto_audio" -> {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                    .build()
                _availableAudioTracks.value = _availableAudioTracks.value.map {
                    it.copy(isSelected = it.id == "auto_audio")
                }
            }
            "off_sub" -> {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                    .build()
                _availableSubtitles.value = _availableSubtitles.value.map {
                    it.copy(isSelected = it.id == "off_sub")
                }
            }
            "auto_video" -> {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .build()
                _availableQualities.value = _availableQualities.value.map {
                    it.copy(isSelected = it.id == "auto_video")
                }
            }
            else -> {
                if (option.trackGroup != null) {
                    val override = TrackSelectionOverride(option.trackGroup, listOf(option.trackIndex))
                    val builder = player.trackSelectionParameters.buildUpon()
                    if (option.id.startsWith("sub_")) {
                        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    }
                    builder.setOverrideForType(override)
                    player.trackSelectionParameters = builder.build()

                    if (option.id.startsWith("audio_")) {
                        _availableAudioTracks.value = _availableAudioTracks.value.map {
                            it.copy(isSelected = it.id == option.id)
                        }
                    } else if (option.id.startsWith("sub_")) {
                        _availableSubtitles.value = _availableSubtitles.value.map {
                            it.copy(isSelected = it.id == option.id)
                        }
                    } else if (option.id.startsWith("video_")) {
                        _availableQualities.value = _availableQualities.value.map {
                            it.copy(isSelected = it.id == option.id)
                        }
                    }
                }
            }
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer?.seekTo(positionMs.coerceAtLeast(0L))
        _currentPosition.value = positionMs
    }

    fun seekBy(offsetMs: Long) {
        val player = exoPlayer ?: return
        val newPos = (player.currentPosition + offsetMs).coerceIn(0L, player.duration.coerceAtLeast(0L))
        player.seekTo(newPos)
        _currentPosition.value = newPos
    }

    fun setSpeed(speed: Float) {
        exoPlayer?.setPlaybackSpeed(speed)
        _playbackSpeed.value = speed
    }

    private fun startPositionTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        val pos = player.currentPosition
                        val dur = player.duration.coerceAtLeast(0L)
                        _currentPosition.value = pos
                        _duration.value = dur
                        onPositionUpdate?.invoke(pos, dur)
                    }
                }
                delay(1000)
            }
        }
    }

    fun play() {
        exoPlayer?.play()
    }

    fun pause() {
        exoPlayer?.pause()
    }

    fun release() {
        tickerJob?.cancel()
        tickerJob = null
        exoPlayer?.let { player ->
            onPositionUpdate?.invoke(player.currentPosition, player.duration)
            player.stop()
            player.release()
        }
        exoPlayer = null
        _exoPlayerInstance.value = null
        _isPlaying.value = false
        _isBuffering.value = false
    }
}
